@extends('layouts.app')
@section('stylesheets')
@endsection
@section('content')
    Help page
@endsection
@section('scripts')
@endsection