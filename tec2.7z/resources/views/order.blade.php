@extends('layouts.app')

@section('content')

    <div class="row align-center">
        <div class="small-12 medium-8 large-6 columns">
            <form id="wizard">
                <h1 class="headline lighter">Afhentning</h1>
                <div class="wizard-content">
                    <input type="text" />
                </div>

                <h1 class="headline lighter">Levering</h1>
                <div class="wizard-content">
                    <input type="text" />
                </div>
            </form>
        </div>
    </div>

@endsection

@section('scripts')
    <script src="js/jquery-3.1.0.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/jquery.steps.min.js"></script>

    <script>
        $("#wizard").steps({
            autofocus : true,
            labels: {
                cancel: "Annuller",
                current: "",
                pagination: "Pagination",
                finish: "Send",
                next: "Næste",
                previous: "Forrige",
                loading: "Loading..."
            }
        });
    </script>
@endsection