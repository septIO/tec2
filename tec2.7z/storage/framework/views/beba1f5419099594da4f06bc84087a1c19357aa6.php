<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="medium-6 medium-offset-3 large-4 large-offset-4 columns ">

            <h1 class="headline lighter text-center">Login</h1>
            <form method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo e(csrf_field()); ?>


                <label>E-Mail Address
                    <input type="email" aria-describedby="emailHelpText" name="email" value="<?php echo e(old('email')); ?>"
                           autofocus>
                </label>
                <?php if($errors->has('email')): ?>
                    <i class="help-text error-text" id="emailHelpText">* <?php echo e($errors->first('email')); ?></i>
                <?php endif; ?>


                <label>Password
                    <input id="password" type="password" name="password">
                </label>
                <?php if($errors->has('password')): ?>
                    <i class="help-text error-text" id="emailHelpText">*<?php echo e($errors->first('password')); ?></i>
                <?php endif; ?>

                <div class="checkbox">
                    <label>
                        <input type="checkbox" name="remember"> Remember Me
                    </label>
                </div>

                <button type="submit" class="button expanded white-text">
                    Login
                </button>

                <a class="pull-left" href="<?php echo e(url('/register')); ?>">
                    Registrer
                </a>

                <a class="pull-right" href="<?php echo e(url('/password/reset')); ?>">
                    Glemt password?
                </a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>