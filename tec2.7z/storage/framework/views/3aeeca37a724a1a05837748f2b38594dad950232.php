<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
    <div class="small-12 columns">
        <h1 class="headline text-center lighter">Login</h1>
    </div>
    </div>
    <div class="row">
        <div class="small-12 medium-6 medium-offset-3 large-4 large-offset-4 columns">

            <form method="post" action="login">
                <?php echo e(csrf_field()); ?>

                <div class="row column log-in-form">
                    <label>Email
                        <input type="text" placeholder="eg.: somebody@example.com">
                    </label>
                    <label>Password
                        <input type="password" placeholder="********">
                    </label>
                    <p><button type="submit" class="button expanded">Log In</button></p>
                    <p class="text-center"><a href="#">Forgot your password?</a></p>
                </div>
            </form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>