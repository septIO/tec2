<!-- Main Content -->
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="medium-6 medium-offset-3 large-4 large-offset-4 columns ">
                <h1 class="headline lighter text-center">Reset Password</h1>
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(url('/password/email')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <label>E-Mail Address
                            <input type="email" aria-describedby="emailHelperText" name="email" value="<?php echo e(old('email')); ?>">
                        </label>

                        <?php if($errors->has('email')): ?>
                            <i class="help-text" id="emailHelperText"> <?php echo e($errors->first('email')); ?></i>
                        <?php endif; ?>

                        <button type="submit" class="button expanded">
                            Send Password Reset Link
                        </button>
                    </form>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>