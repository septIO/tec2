<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="small-12 medium-6 medium-offset-3 large-4 large-offset-4 columns">
            <h1 class="headline lighter text-center">Register</h1>

            <form method="POST" action="<?php echo e(url('/register')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name">Name</label>

                    <input id="name" type="text" class="form-control" aria-describedby="nameHelpText" name="name"
                           value="<?php echo e(old('name')); ?>" autofocus>
                    <?php if($errors->has('name')): ?>
                        <p class="help-text error-text" id="nameHelpText">* <?php echo e($errors->first('name')); ?></p>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email">E-Mail Address</label>

                    <input id="email" type="email" class="form-control" aria-describedby="emailHelpText" name="email"
                           value="<?php echo e(old('email')); ?>">

                    <?php if($errors->has('email')): ?>
                        <p class="help-text error-text" id="emailHelpText">* <?php echo e($errors->first('email')); ?></p>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password">Password</label>

                    <input id="password" type="password" aria-describedby="passwordHelpText" class="form-control"
                           name="password">

                    <?php if($errors->has('password')): ?>
                        <p class="help-text error-text" id="passwordHelpText">* <?php echo e($errors->first('password')); ?></p>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                    <label for="password-confirm">Confirm Password</label>

                    <input id="password-confirm" type="password" aria-describedby="confirmHelpText" class="form-control"
                           name="password_confirmation">

                    <?php if($errors->has('password_confirmation')): ?>
                        <p class="help-text error-text" id="confirmHelpText">
                            * <?php echo e($errors->first('password_confirmation')); ?></p>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <button type="submit" class="button expanded text-white">
                        Register
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>